<!DOCTYPE html>
<html>
    <head>   
        <link href="style-new1.css" type="text/css" rel="stylesheet" />
        <link href="bg.css" rel="stylesheet" type="text/css">
        <link href="style.css" type="text/css" rel="stylesheet" />
    </head>
    <body>
        
        <nav class='hero'>
	    <nav class="navtop">
	    	<div>
	    		<h1>Event Calendar</h1>
	    	</div>
	    </nav>
		<div class="content home">
			<?=$calendar?>
		</div>
        <?php
        include 'Calendar-new1.php';
        
        $calendar = new Calendar();

        
        echo $calendar->show();
        ?>

        <input type="button" value="Add New Event" onclick="location='add event-new1.php'">

    </body>
</html>  